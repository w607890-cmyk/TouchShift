package com.example.touchshift

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.MotionEvent
import android.view.View
import android.widget.*
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : Activity() {
    private var distanceCm = 1.0f
    private var angleDeg = 270f // up
    private lateinit var canvasView: DemoCanvas

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(248, 248, 250))
        }

        val title = TextView(this).apply {
            text = "TouchShift 1.0"
            textSize = 26f
            setTextColor(Color.BLACK)
        }
        root.addView(title)

        val note = TextView(this).apply {
            text = "ДЕМО: проверь смещение внутри этой области. Это пока не меняет касания в ibis Paint X."
            textSize = 14f
            setPadding(0, 12, 0, 12)
            setTextColor(Color.DKGRAY)
        }
        root.addView(note)

        val distanceLabel = TextView(this).apply { textSize = 16f }
        root.addView(distanceLabel)

        val seek = SeekBar(this).apply {
            max = 50
            progress = 10
        }
        root.addView(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                distanceCm = p / 10f
                distanceLabel.text = "Расстояние: %.1f см".format(distanceCm)
                canvasView.invalidate()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        distanceLabel.text = "Расстояние: 1.0 см"

        val directionLabel = TextView(this).apply {
            text = "Направление"
            textSize = 16f
            setPadding(0, 12, 0, 4)
        }
        root.addView(directionLabel)

        val directions = listOf("Вверх", "Вправо", "Вниз", "Влево",
            "Вверх-вправо", "Вниз-вправо", "Вниз-влево", "Вверх-влево")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, directions)
        root.addView(spinner)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                angleDeg = listOf(270f, 0f, 90f, 180f, 315f, 45f, 135f, 225f)[position]
                canvasView.invalidate()
            }
        }

        canvasView = DemoCanvas()
        root.addView(canvasView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val clear = Button(this).apply {
            text = "Очистить тест"
            setOnClickListener { canvasView.clear() }
        }
        root.addView(clear)

        setContentView(root)
    }

    inner class DemoCanvas : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val marks = mutableListOf<Pair<Float, Float>>()
        private var lastTouch: Pair<Float, Float>? = null

        init { setBackgroundColor(Color.WHITE) }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            paint.color = Color.LTGRAY
            paint.strokeWidth = 2f
            canvas.drawLine(width / 2f, 0f, width / 2f, height.toFloat(), paint)
            canvas.drawLine(0f, height / 2f, width.toFloat(), height / 2f, paint)

            paint.color = Color.rgb(30, 120, 220)
            paint.strokeWidth = 5f
            marks.forEach { canvas.drawCircle(it.first, it.second, 7f, paint) }

            lastTouch?.let { (x, y) ->
                val pxPerCm = resources.displayMetrics.xdpi / 2.54f
                val rad = Math.toRadians(angleDeg.toDouble())
                val dx = cos(rad).toFloat() * distanceCm * pxPerCm
                val dy = sin(rad).toFloat() * distanceCm * pxPerCm

                paint.color = Color.GRAY
                paint.strokeWidth = 3f
                paint.style = Paint.Style.STROKE
                canvas.drawCircle(x, y, 12f, paint)
                paint.style = Paint.Style.FILL

                paint.color = Color.rgb(220, 70, 60)
                canvas.drawCircle(x + dx, y + dy, 9f, paint)
                paint.color = Color.DKGRAY
                paint.textSize = 28f
                canvas.drawText("Касание", 16f, 36f, paint)
                canvas.drawText("Смещённая точка", 16f, 70f, paint)
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    lastTouch = event.x to event.y
                    invalidate()
                }
                MotionEvent.ACTION_UP -> {
                    val x = event.x
                    val y = event.y
                    val pxPerCm = resources.displayMetrics.xdpi / 2.54f
                    val rad = Math.toRadians(angleDeg.toDouble())
                    marks.add((x + cos(rad).toFloat() * distanceCm * pxPerCm) to
                              (y + sin(rad).toFloat() * distanceCm * pxPerCm))
                    lastTouch = null
                    invalidate()
                }
                MotionEvent.ACTION_CANCEL -> {
                    lastTouch = null
                    invalidate()
                }
            }
            return true
        }

        fun clear() {
            marks.clear()
            lastTouch = null
            invalidate()
        }
    }
}
